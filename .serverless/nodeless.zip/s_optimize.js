
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'pedromazo',
  applicationName: 'nodeless',
  appUid: 'wTsRs8C4tPZDXtFM3W',
  orgUid: 'f1ad6026-b2f4-40a0-89d6-4904d5d29de2',
  deploymentUid: '4e9b1edc-7bc0-46bd-996b-56320c84bc38',
  serviceName: 'nodeless',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '5.5.0',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'nodeless-dev-optimize', timeout: 6 };

try {
  const userHandler = require('./optimize.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handle, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}